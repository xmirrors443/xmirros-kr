module kraken-proxy

go 1.21

require (
	github.com/refraction-networking/utls v1.6.0
	golang.org/x/net v0.19.0
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/cloudflare/circl v1.3.4 // indirect
	github.com/klauspost/compress v1.17.2 // indirect
	golang.org/x/crypto v0.17.0 // indirect
	golang.org/x/sys v0.15.0 // indirect
)
