package session

import (
	"fmt"
	"net/http"
	"net/url"
	"sync"

	"kraken-proxy/config"
)

type Session struct {
	Scheme  string
	Host    string
	Cookies map[string]*http.Cookie
	mu      sync.RWMutex
}

var (
	sessions   = make(map[string]*Session)
	mu         sync.RWMutex
	sessionGen = 0
)

func GetOrCreate(r *http.Request, cfg *config.Config, targetURL string) (string, *Session) {
	sidCookie, _ := r.Cookie(cfg.SessionName)

	if sidCookie != nil {
		mu.RLock()
		sess := sessions[sidCookie.Value]
		mu.RUnlock()
		if sess != nil {
			return sidCookie.Value, sess
		}
	}

	u, _ := url.Parse(targetURL)
	sess := &Session{
		Scheme:  u.Scheme,
		Host:    u.Host,
		Cookies: make(map[string]*http.Cookie),
	}

	mu.Lock()
	sessionGen++
	sid := fmt.Sprintf("sess%d", sessionGen)
	sessions[sid] = sess
	mu.Unlock()

	return sid, sess
}

func (s *Session) UpdateCookies(resp *http.Response) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, c := range resp.Cookies() {
		s.Cookies[c.Name] = c
	}
}

func (s *Session) GetCookies() []*http.Cookie {
	s.mu.RLock()
	defer s.mu.RUnlock()
	res := make([]*http.Cookie, 0, len(s.Cookies))
	for _, c := range s.Cookies {
		res = append(res, c)
	}
	return res
}

func CookieNames(cookies []*http.Cookie) []string {
	names := make([]string, len(cookies))
	for i, c := range cookies {
		names[i] = c.Name
	}
	return names
}

func (s *Session) HasTCK() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.Cookies["TCK"] != nil
}

func (s *Session) SetTCK(value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Cookies["TCK"] = &http.Cookie{Name: "TCK", Value: value}
}

func (s *Session) UpdateScheme(scheme, host string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Scheme = scheme
	s.Host = host
}
