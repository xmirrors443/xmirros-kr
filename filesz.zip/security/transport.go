package security

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"time"

	utls "github.com/refraction-networking/utls"
	"golang.org/x/net/http2"
	"golang.org/x/net/proxy"
)

// TLSDialer для HTTPS соединений через uTLS
type TLSDialer struct {
	dialer proxy.Dialer
}

func (td *TLSDialer) Dial(network, addr string) (net.Conn, error) {
	conn, err := td.dialer.Dial(network, addr)
	if err != nil {
		return nil, err
	}

	host, _, _ := net.SplitHostPort(addr)

	// uTLS с Chrome 120 fingerprint
	config := &utls.Config{
		ServerName:         host,
		InsecureSkipVerify: true,
		NextProtos:         []string{"h2", "http/1.1"},
	}
	uconn := utls.UClient(conn, config, utls.HelloChrome_120)

	if err := uconn.Handshake(); err != nil {
		conn.Close()
		return nil, fmt.Errorf("uTLS handshake failed: %w", err)
	}

	return uconn, nil
}

// NewHTTP2Transport создает HTTP/2 транспорт через Tor
func NewHTTP2Transport(socksAddr string) (*http2.Transport, error) {
	socksURL, _ := url.Parse("socks5h://" + socksAddr)
	dialer, err := proxy.FromURL(socksURL, proxy.Direct)
	if err != nil {
		return nil, fmt.Errorf("SOCKS5h dialer: %w", err)
	}

	tlsDialer := &TLSDialer{dialer: dialer}

	h2Transport := &http2.Transport{
		DialTLS: func(network, addr string, cfg *utls.Config) (net.Conn, error) {
			return tlsDialer.Dial(network, addr)
		},
		AllowHTTP: false,
	}

	return h2Transport, nil
}

// NewHTTP1Transport создает HTTP/1.1 транспорт через Tor
func NewHTTP1Transport(socksAddr string) (*http.Transport, error) {
	socksURL, _ := url.Parse("socks5h://" + socksAddr)
	dialer, err := proxy.FromURL(socksURL, proxy.Direct)
	if err != nil {
		return nil, fmt.Errorf("SOCKS5h dialer: %w", err)
	}

	tlsDialer := &TLSDialer{dialer: dialer}

	return &http.Transport{
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			return dialer.Dial(network, addr)
		},
		DialTLSContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			return tlsDialer.Dial(network, addr)
		},
		MaxIdleConns:      100,
		IdleConnTimeout:   90 * time.Second,
		DisableKeepAlives: false,
	}, nil
}
