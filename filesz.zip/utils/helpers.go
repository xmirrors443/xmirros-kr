package utils

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/hex"
	"fmt"
	"regexp"
	"strings"
)

var StaticExtensions = []string{".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff", ".woff2", ".ttf", ".eot", ".map"}

// IsStaticAsset проверяет является ли путь статическим ассетом
func IsStaticAsset(path string) bool {
	lower := strings.ToLower(path)
	for _, ext := range StaticExtensions {
		if strings.HasSuffix(lower, ext) {
			return true
		}
	}
	return false
}

// ComputeTCKFromJS вычисляет TCK из JavaScript кода
func ComputeTCKFromJS(body []byte) (string, error) {
	re := regexp.MustCompile(`toNumbers\("([^"]+)"\)`)
	matches := re.FindAllStringSubmatch(string(body), 3)
	if len(matches) < 3 {
		return "", fmt.Errorf("не найдены параметры AES")
	}
	a, _ := hex.DecodeString(matches[0][1])
	b, _ := hex.DecodeString(matches[1][1])
	c, _ := hex.DecodeString(matches[2][1])

	block, _ := aes.NewCipher(a)
	mode := cipher.NewCBCDecrypter(block, b)
	plain := make([]byte, len(c))
	mode.CryptBlocks(plain, c)
	if pad := int(plain[len(plain)-1]); pad > 0 && pad <= block.BlockSize() {
		plain = plain[:len(plain)-pad]
	}
	return hex.EncodeToString(plain), nil
}
