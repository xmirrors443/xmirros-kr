package config

import (
	"os"
	"strconv"
)

type Config struct {
	ProxyHost           string
	TorInstances        int
	TorSocksBasePort    int
	InitialTarget       string
	SessionName         string
	MirrorLink          string
	WalletBTC           string
	MirrorKraken2       string
	MirrorKraken3       string
	MirrorKraken4       string
}

func Load() *Config {
	torInstances := 3
	if val, err := strconv.Atoi(getEnv("TOR_INSTANCES", "3")); err == nil {
		torInstances = val
	}

	torSocksBasePort := 9050
	if val, err := strconv.Atoi(getEnv("TOR_SOCKS_BASE_PORT", "9050")); err == nil {
		torSocksBasePort = val
	}

	return &Config{
		ProxyHost:        getEnv("PROXY_HOST", "localhost:8080"),
		TorInstances:     torInstances,
		TorSocksBasePort: torSocksBasePort,
		InitialTarget:    getEnv("INITIAL_TARGET", "http://kraken2trfqodidvlh4aa337cpzfrhdlfldhve5nf7njhumwr7instad.onion"),
		SessionName:      getEnv("SESSION_NAME", "sid"),
		MirrorLink:       getEnv("MIRROR_LINK", "kraken2trfqodidvlh4aa337cpzfrhdlfldhve5nf7njhumwr7instad.onion"),
		WalletBTC:        getEnv("WALLET_BTC", "bc1qmqgq9kvhwprxnrwkmu09xgjezucn9wkcf8s2gg"),
		MirrorKraken2:    getEnv("MIRROR_KRAKEN2", "kraken2trfqodidvlh4aa337cpzfrhdlfldhve5nf7njhumwr7instad.onion"),
		MirrorKraken3:    getEnv("MIRROR_KRAKEN3", "kraken3yvbvzmhytnrnuhsy772i6dfobofu652e27f5hx6y5cpj7rgyd.onion"),
		MirrorKraken4:    getEnv("MIRROR_KRAKEN4", "kraken4qzqnoi7ogpzpzwrxk7mw53n5i56loydwiyonu4owxsh4g67yd.onion"),
	}
}

func getEnv(key, defaultVal string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultVal
}

