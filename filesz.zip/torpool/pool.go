package torpool

import (
	"fmt"
	"log"
	"net/http"
	"sync"
	"sync/atomic"

	"kraken-proxy/security"
)

// TorInstance представляет один Tor инстанс
type TorInstance struct {
	ID        int
	Host      string
	Port      int
	Transport *http.Transport
}

// Pool управляет пулом Tor инстансов
type Pool struct {
	instances []*TorInstance
	counter   uint64
	mu        sync.RWMutex
}

// NewPool создает новый пул Tor инстансов
func NewPool(basePort int, count int) (*Pool, error) {
	pool := &Pool{
		instances: make([]*TorInstance, 0, count),
	}

	for i := 0; i < count; i++ {
		port := basePort + i
		addr := fmt.Sprintf("127.0.0.1:%d", port)

		// Создаем транспорт для этого инстанса
		transport, err := security.NewHTTP1Transport(addr)
		if err != nil {
			log.Printf("[TORPOOL] Ошибка создания транспорта для инстанса %d (%s): %v", i, addr, err)
			continue
		}

		instance := &TorInstance{
			ID:        i,
			Host:      "127.0.0.1",
			Port:      port,
			Transport: transport,
		}

		pool.instances = append(pool.instances, instance)
		log.Printf("[TORPOOL] Инстанс %d создан: %s:%d", i, instance.Host, instance.Port)
	}

	if len(pool.instances) == 0 {
		return nil, fmt.Errorf("не удалось создать ни один Tor инстанс")
	}

	return pool, nil
}

// GetInstance возвращает следующий инстанс (round-robin)
func (p *Pool) GetInstance() *TorInstance {
	if len(p.instances) == 0 {
		return nil
	}

	// Round-robin балансировка
	idx := atomic.AddUint64(&p.counter, 1) % uint64(len(p.instances))
	return p.instances[idx]
}

// GetInstanceByID возвращает инстанс по ID
func (p *Pool) GetInstanceByID(id int) *TorInstance {
	p.mu.RLock()
	defer p.mu.RUnlock()

	for _, inst := range p.instances {
		if inst.ID == id {
			return inst
		}
	}
	return nil
}

// Count возвращает количество инстансов
func (p *Pool) Count() int {
	return len(p.instances)
}

// List возвращает список всех инстансов
func (p *Pool) List() []*TorInstance {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.instances
}
