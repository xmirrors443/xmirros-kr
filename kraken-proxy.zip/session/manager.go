package session

import (
	"fmt"
	"net/http"
	"sync"
	"net/url"
)

// Session представляет пользовательскую сессию
type Session struct {
	Scheme  string
	Host    string
	Cookies map[string]*http.Cookie
	mu      sync.RWMutex
}

// Manager управляет сессиями
type Manager struct {
	sessions   map[string]*Session
	mu         sync.RWMutex
	sessionGen int
}

// NewManager создает новый менеджер сессий
func NewManager() *Manager {
	return &Manager{
		sessions: make(map[string]*Session),
	}
}

// GetOrCreate получает существующую сессию или создает новую
func (m *Manager) GetOrCreate(sidCookie *http.Cookie, targetURL string) (string, *Session) {
	if sidCookie != nil {
		m.mu.RLock()
		session, exists := m.sessions[sidCookie.Value]
		m.mu.RUnlock()
		if exists {
			return sidCookie.Value, session
		}
	}

	// Создаем новую сессию
	u, _ := url.Parse(targetURL)
	session := &Session{
		Scheme:  u.Scheme,
		Host:    u.Host,
		Cookies: make(map[string]*http.Cookie),
	}

	m.mu.Lock()
	m.sessionGen++
	sid := fmt.Sprintf("sess%d", m.sessionGen)
	m.sessions[sid] = session
	m.mu.Unlock()

	return sid, session
}

// UpdateCookies обновляет cookies в сессии
func (s *Session) UpdateCookies(resp *http.Response) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, c := range resp.Cookies() {
		s.Cookies[c.Name] = c
	}
}

// GetCookies получает все cookies из сессии
func (s *Session) GetCookies() []*http.Cookie {
	s.mu.RLock()
	defer s.mu.RUnlock()
	res := make([]*http.Cookie, 0, len(s.Cookies))
	for _, c := range s.Cookies {
		res = append(res, c)
	}
	return res
}

// CookieNames возвращает список имен cookies
func CookieNames(cookies []*http.Cookie) []string {
	names := make([]string, len(cookies))
	for i, c := range cookies {
		names[i] = c.Name
	}
	return names
}

// HasTCK проверяет наличие TCK
func (s *Session) HasTCK() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.Cookies["TCK"] != nil
}

// UpdateScheme обновляет схему и хост
func (s *Session) UpdateScheme(scheme, host string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Scheme = scheme
	s.Host = host
}

// SetTCK устанавливает TCK cookie
func (s *Session) SetTCK(value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Cookies["TCK"] = &http.Cookie{Name: "TCK", Value: value}
}
