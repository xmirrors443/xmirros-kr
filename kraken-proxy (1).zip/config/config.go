package config

import (
	"os"
	"strconv"
)

type Config struct {
	ProxyHost     string
	TorPort       int
	InitialTarget string
	SessionName   string
	MirrorLink    string
	WalletBTC     string
}

func Load() *Config {
	torPort := 9050
	if val, err := strconv.Atoi(getEnv("TOR_PORT", "9050")); err == nil {
		torPort = val
	}

	return &Config{
		ProxyHost:     getEnv("PROXY_HOST", "localhost:8080"),
		TorPort:       torPort,
		InitialTarget: getEnv("INITIAL_TARGET", "http://kraken2trfqodidvlh4aa337cpzfrhdlfldhve5nf7njhumwr7instad.onion"),
		SessionName:   getEnv("SESSION_NAME", "sid"),
		MirrorLink:    getEnv("MIRROR_LINK", "kraken2trfqodidvlh4aa337cpzfrhdlfldhve5nf7njhumwr7instad.onion"),
		WalletBTC:     getEnv("WALLET_BTC", "bc1qmqgq9kvhwprxnrwkmu09xgjezucn9wkcf8s2gg"),
	}
}

func getEnv(key, defaultVal string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultVal
}
